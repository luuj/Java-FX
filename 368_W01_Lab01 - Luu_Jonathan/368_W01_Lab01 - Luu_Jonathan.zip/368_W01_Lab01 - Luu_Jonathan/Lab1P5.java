/* Name: Jonathan Luu
 * Date: August 27, 2016
 */

public class Lab1P5 {
  //No hints this time.  Work on this until you get it to compile, then run it

  public static void main (String[] args) {
    int firstInt, secondInt;

    firstInt = 5;
    secondInt = 10;

    System.out.println( "firstInt is: " + firstInt) ;
    System.out.println( "secondInt is: " + secondInt );
  }
}
