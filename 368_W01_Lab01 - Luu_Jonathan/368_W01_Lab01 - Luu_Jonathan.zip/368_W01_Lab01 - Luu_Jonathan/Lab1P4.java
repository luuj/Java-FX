/* Name: Jonathan Luu
 * Date: August 27, 2016
 */

public class Lab1P4 {
  //This program has three errors in it.  One error occurs in two places.
  //So, you can fix two of the errors at the same time.  Also, I'll give
  //you a hint.  The two related errors won't show up until you fix the
  //first error.

  public static void main (String[] args) {
    int firstInt, secondInt, answer;

    firstInt = 5;
    secondInt = 10;
    answer = firstInt + secondInt;

    System.out.println( "firstInt is: " + firstInt );
    System.out.println( "secondInt is: " + secondInt );
    System.out.println( "The sum of the two numbers is: " + answer );
  }
}
