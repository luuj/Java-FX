/* Name: Jonathan Luu
 * Date: August 27, 2016
 */

//Lab1P8.java - Eclipse gives a warning on this and won't run it until you fix the problem.
//Notice the yellow  line. Eclipse lets  you run it, but you get a runtime error.
//The yellow line is warning you that you are likely to have a runtime error.

public class Lab1P8 {

  public static void main (String[] args) {
    String myString = null;
    
    System.out.println( "myString is:" + myString );
  }
  
}