/* Name: Jonathan Luu
 * Date: August 27, 2016
 */

public class Lab1P3 {
  /*
    This is the last one where I tell you the problem.  This program
    has the class name different from the file name.  The only difference
    is the lower-case p.  This is to reinforce the requirement that the
    name of the file and the name of the public class must be identical

	This one you can miss in Eclipse. That is because the red square is on the
	very first line of code.
	
	
	Fix the class name so that it is Lab1P3 - a captial 'P'.
	
    Note that this error message from the compiler is actually pretty helpful
  */

  public static void main (String[] args) {
    System.out.println("This is the first line");
    System.out.println("This is the second line");
  }
}
